package corvus.test;

import hk.hku.cecid.piazza.commons.servlet.RequestListenerException;
import hk.hku.cecid.piazza.commons.servlet.http.HttpRequestAdaptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Comment for TestInboundListener.java.
 *
 * @author kochiu
 * @version $Revision$
 */
public class TestInboundListener extends HttpRequestAdaptor {
    /**
     * processRequest
     * @param request
     * @param response
     * @return
     * @throws RequestListenerException
     * @see hk.hku.cecid.piazza.commons.servlet.http.HttpRequestListener#processRequest(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public String processRequest(HttpServletRequest request,
            HttpServletResponse response) throws RequestListenerException {
        try {
            System.out.println("Received a request !");
            return null;
        }
        catch (Exception e) {
            throw new RequestListenerException("Error in processing AS2 request", e);
        }
    }
}
