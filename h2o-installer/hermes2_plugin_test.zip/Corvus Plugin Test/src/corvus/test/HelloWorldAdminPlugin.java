package corvus.test;

import hk.hku.cecid.piazza.commons.util.PropertyTree;
import hk.hku.cecid.piazza.corvus.admin.listener.AdminPageletAdaptor;

import javax.servlet.http.HttpServletRequest;
import javax.xml.transform.Source;

/**
 * Comment for HelloWorldAdminPlugin.java.
 *
 * @author kochiu
 * @version $Revision$
 */
public class HelloWorldAdminPlugin extends AdminPageletAdaptor {
    protected Source getCenterSource(HttpServletRequest request) {
        PropertyTree dom = new PropertyTree();

        dom.setProperty("test_content", "Hello World");

        return dom.getSource();
    }
}
